# CLI_Mailer
This is a python package that let's you send mail over command line interface.
### USAGE 
1. Install the Package
```bash
pip install cli-mailer
```
2. Now run the script (from anywhere)
```bash
cli-mailer
```

